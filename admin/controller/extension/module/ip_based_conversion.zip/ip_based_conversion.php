<?php
class ControllerExtensionModuleIpBasedConversion extends Controller {

    public function install() {
        $this->load->model('user/user_group');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'access', 'extension/module/ip_based_conversion');
        $this->model_user_user_group->addPermission($this->user->getGroupId(), 'modify', 'extension/module/ip_based_conversion');
    }

    public function uninstall() {
        $this->load->model('user/user_group');
        
        // Note: OpenCart does not provide a built-in method to remove permissions.
        // You would need to execute a database query to remove the permissions.
        $this->db->query("DELETE FROM " . DB_PREFIX . "user_group WHERE name = 'extension/module/custom_options'");
    }
    public function index() {
        // Load required models and language files
        $this->load->language('extension/module/ip_based_conversion');
        $this->document->setTitle($this->language->get('heading_title'));
        $data['heading_title'] = $this->language->get('heading_title');
        $data['breadcrumbs'] = array(
            array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
            ),
            array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/ip_based_conversion', 'user_token=' . $this->session->data['user_token'], true)
            )
        );
        $data['error_warning'] = @$this->session->data['error_warning_bulk'];
        $data['success'] = @$this->session->data['success_bulk'];
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
        $data['add_new'] = $this->url->link('extension/module/ip_based_conversion/addSaleOptions', 'user_token=' . $this->session->data['user_token'], true);
        $data['user_token'] = $this->session->data['user_token'];
        
        
        $this->load->model('catalog/product');
        $this->load->model('catalog/category');

        $data['conversions'] = $this->model_catalog_product->getConversions();
		$data['action'] = $this->url->link('extension/module/ip_based_conversion/addSaleOptionsProcess', 'user_token=' . $this->session->data['user_token'], true);

        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->load->model('extension/module/ip_based_conversion');
        $data['listingData'] = $this->model_extension_module_ip_based_conversion->getListingData();
        $this->response->setOutput($this->load->view('extension/module/ip_based_conversion', $data));
    }

    public function addSaleOptions() {
        
        $this->load->language('extension/module/ip_based_conversion');
        $this->document->setTitle($this->language->get('heading_title'));
        $data['heading_title'] = $this->language->get('heading_title');
        $data['breadcrumbs'] = array(
            array(
                'text' => $this->language->get('text_home'),
                'href' => $this->url->link('common/dashboard', 'user_token=' . $this->session->data['user_token'], true)
            ),
            array(
                'text' => $this->language->get('heading_title'),
                'href' => $this->url->link('extension/module/ip_based_conversion', 'user_token=' . $this->session->data['user_token'], true)
            )
        );
        $data['button_cancel'] = $this->language->get('button_cancel');
        $data['cancel'] = $this->url->link('marketplace/extension', 'user_token=' . $this->session->data['user_token'] . '&type=module', true);
        $this->load->model('catalog/product');
        
        $data['countries'] = $this->model_catalog_product->getCountriesList();
        $data['currencies'] = $this->model_catalog_product->getCurrenciesList();
        $data['languages'] = $this->model_catalog_product->getLanguagesList();

		$data['action'] = $this->url->link('extension/module/ip_based_conversion/addSaleOptionsProcess', 'user_token=' . $this->session->data['user_token'], true);
        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');
        $this->response->setOutput($this->load->view('extension/module/ip_based_conversion_form_add', $data));
    }
    
    public function addSaleOptionsProcess() {
        $this->load->model('extension/module/ip_based_conversion');
        $this->model_extension_module_ip_based_conversion->addOption($_POST);
        $this->session->data['success_bulk'] = "Conversion has been successfully created.";
        $this->response->redirect($this->url->link('extension/module/ip_based_conversion', 'user_token=' . $this->session->data['user_token']));
    }

    function deleteSaleOptions() {
        if( isset($_POST['conversion_id']) && $_POST['conversion_id'] != '' && is_numeric($_POST['conversion_id']) && $_POST['conversion_id'] > 0 ) {
            $this->load->model('extension/module/ip_based_conversion');
            $this->model_extension_module_ip_based_conversion->deleteOption($_POST);
        }
    }
}
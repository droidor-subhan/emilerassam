<?php
// Heading
$_['heading_title'] = 'IP-Based Language and Currency Conversion';

// Text
$_['text_success'] = 'Success: Conversion added successfully!';

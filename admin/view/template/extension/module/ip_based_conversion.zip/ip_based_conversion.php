<?php
// Heading
$_['heading_title'] = 'Custom Options';

// Text
$_['text_success'] = 'Success: Option added successfully!';

<?php
class ModelExtensionModuleIpBasedConversion extends Model {
    public function addOption($data) {
        if( isset($data) && $data != '' && is_array($data) && count($data) > 0 ) {
            if( isset($data['country_id']) && $data['country_id'] != '' ) {
                $this->db->query("INSERT INTO " . DB_PREFIX . "localization_preferences SET
                    country_name = '" . $this->db->escape($_POST['country_name']) . "',
                    country_ios_2 = '" . $this->db->escape($_POST['country_id']) . "',
                    language_id = '" . $this->db->escape($_POST['language_id']) . "',
                    currency_id = '" . $this->db->escape($_POST['currency_id']) . "' 
                ");
            }
        }
    }
    public function getListingData() {
        $bulk_sale_array = array();
        $query = $this->db->query("SELECT * FROM " . DB_PREFIX . "product_bulk_special ORDER BY id DESC");
        if( isset($query->rows) && count($query->rows) > 0  ) {
            foreach ($query->rows as $key => $row) {
                $bulk_sale_array[$key]['id'] = $row['id'];
                $bulk_sale_array[$key]['discount_type'] = $row['discount_type'];
                $bulk_sale_array[$key]['discount_value'] = $row['discount_value'];
                if( isset($row['id']) && $row['id'] != '' ) {
                    $query_sale_products = $this->db->query("SELECT " . DB_PREFIX . "product_special.*, " . DB_PREFIX . "product_description.name FROM " . DB_PREFIX . "product_special LEFT JOIN " . DB_PREFIX . "product_description ON (" . DB_PREFIX . "product_special.product_id = " . DB_PREFIX . "product_description.product_id) where product_bulk_special_id = '".$row['id']."' ");
                    if( isset($query_sale_products->rows) && count($query_sale_products->rows) > 0  ) {
                        $date_start = "0000-00-00";
                        $date_end = "0000-00-00";
                        foreach ($query_sale_products->rows as $key_inner => $product_row) {
                            $bulk_sale_array[$key]['products'][] = $product_row['name'];
                            $date_start = $product_row['date_start'];
                            $date_end = $product_row['date_end'];
                        }
                        $bulk_sale_array[$key]['date_start'] = $date_start;
                        $bulk_sale_array[$key]['date_end'] = $date_end;
                    }
                }

            }
        }
        return $bulk_sale_array;
    }

    public function deleteOption() {
        if( isset($_POST['conversion_id']) && $_POST['conversion_id'] > 0 ) {    
            $this->db->query("DELETE FROM " . DB_PREFIX . "localization_preferences WHERE localization_preferences_id = '".$_POST['conversion_id']."' ");
        }
    }
}